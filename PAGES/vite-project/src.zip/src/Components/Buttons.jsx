import React from 'react'



const Buttons = () => {
  return (
    <button id="upload_data" className="btn hover:bg-blue-200 focus:ring-blue-800">Upload</button>
  )
}

export default Buttons